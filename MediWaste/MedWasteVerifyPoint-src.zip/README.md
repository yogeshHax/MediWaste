# MedWaste VerifyPoint

A physical medicine-waste intake and verification station connected to a professional web application.

**This is an intake and review-support system, not a certified pharmaceutical authentication device.**

## Project structure

- `src/app/` — Next.js App Router frontend (12 pages)
- `src/backend/` — Firebase Cloud Functions (business logic, authorisation)
- `src/types/` — shared domain models and Zod validation schemas
- `src/lib/` — Firebase client init, helper utilities
- `src/hardware/bridge/` — Node.js hardware bridge (serial / HC-05 Bluetooth)
- `src/hardware/firmware/` — Arduino C++ firmware for the verification station
- `src/hardware/simulator/` — hardware simulator for development and demos
- `src/tests/` — Playwright end-to-end tests
- `docs/` — setup, architecture, and runbook documentation

## Prerequisites

- Node.js 20+
- npm 10+
- Firebase CLI (`npm install -g firebase-tools`) for emulators and deployment
- Arduino IDE or `arduino-cli` for firmware (optional, for physical hardware)

## Local setup

1. `npm install`
2. Copy `.env.example` to `.env.local` and fill in your values.
3. Start the Firebase emulators: `npm run emu`
4. In another terminal, start the hardware simulator: `npm run simulator`
5. In another terminal, start the Next.js dev server: `npm run dev`
6. Open http://localhost:3000

See `docs/` for full setup, architecture, and runbook details.

## Environment variables

See `.env.example`. **Never commit real credentials.**

## Export

To export a clean copy of this project (excluding `node_modules`, build caches, and secrets):

```bash
npm install
npm run build  # optional: verify build
# then zip the repo excluding node_modules/.next/.env*
```

See the project's export instructions for the verified download location.
