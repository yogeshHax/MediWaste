# MedWaste VerifyPoint — Agent guidance

## Project

- Next.js 15 (App Router), React 19, TypeScript, Tailwind CSS
- Firebase Auth + Firestore + Cloud Functions + Emulator Suite
- Node.js hardware bridge (serial/HC-05), Arduino firmware, simulator
- shadcn/ui components in `src/components/ui/`

## Conventions

- Use `@/` imports for `src/`.
- Keep backend business logic and authorisation in Cloud Functions, not client-side.
- Validate all inputs with Zod; share schemas in `src/types/`.
- Never commit secrets. Use `.env.example` placeholders only.
- Hardware events must never independently authorise acceptance; gate default is CLOSED.

## Firebase

Run emulators locally:
- `npm run emu` — auth + firestore
- `npm run functions:emulator` — cloud functions

## Hardware

- Firmware: `src/hardware/firmware/` (Arduino C++)
- Bridge: `src/hardware/bridge/index.js` (Node.js serial/HC-05)
- Simulator: `src/hardware/simulator/index.js` (dev/demo)
