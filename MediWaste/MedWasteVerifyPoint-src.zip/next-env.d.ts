/// <reference types="next" />\n/// <reference types="react" />\n/// <reference types="react-dom" />
