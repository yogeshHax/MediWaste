import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        medical: {
          50: "#f0f7f4",
          100: "#d9ece3",
          200: "#b6d7c7",
          300: "#8fc0a8",
          400: "#67a585",
          500: "#4a8a63",
          600: "#3d7253",
          700: "#345b42",
          800: "#2c4835",
          900: "#233b2b",
          950: "#0f1c14",
        },
        station: {
          green: "#22c55e",
          red: "#ef4444",
          amber: "#f59e0b",
          blue: "#3b82f6",
        },
      },
      fontFamily: {
        sans: ["var(--font-inter)", "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
};

export default config;
