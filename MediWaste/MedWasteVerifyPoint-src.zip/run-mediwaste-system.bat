@echo off
setlocal EnableDelayedExpansion

:: ============================================================================
:: MedWaste VerifyPoint - full local system runner
:: Opens separate windows for:
::   1) Firebase emulators (auth + firestore)
::   2) Hardware simulator (Node.js)
::   3) Next.js dev server
::
:: Toolkit-only:
::   - Firebase emulators require firebase-tools on PATH (npm i -g firebase-tools).
::     If unavailable, this script warns and skips the emulator window.
::   - Hardware simulator requires no extra global install (node is enough).
::   - Next.js dev server is started via npx (no global install required).
:: ============================================================================

set "REPO_DIR=%~dp0"
set "ERRORS=0"

echo ============================================
echo  MedWaste VerifyPoint - full system runner
echo  Working directory: %REPO_DIR%
echo ============================================
echo.

:: --------------------------------------------------------------------
:: 1) Firebase emulators (optional - requires firebase-tools)
:: --------------------------------------------------------------------
echo [1/3] Firebase emulators (auth, firestore)...
where firebase >/dev/null 2>/dev/null
if %ERRORLEVEL% NEQ 0 (
    echo WARNING: 'firebase' not found on PATH.
    echo         Install with:  npm install -g firebase-tools
    echo         Or run manually:  npm run emu
    echo.
    set "SKIP_EMU=1"
) else (
    echo Starting Firebase emulators in a separate window...
    cd /d "%REPO_DIR%"
    start "Firebase Emulators" cmd /k "firebase emulators:start --only auth,firestore"
    if %ERRORLEVEL% NEQ 0 (
        echo WARNING: Failed to launch Firebase emulators window.
        set "ERRORS=!ERRORS!1"
    )
)

:: Give the emulator window a moment to start before opening others
timeout /t 3 /nobreak >/dev/null 2>&1

:: --------------------------------------------------------------------
:: 2) Hardware simulator (optional - node only)
:: --------------------------------------------------------------------
echo [2/3] Hardware simulator...
cd /d "%REPO_DIR%"
echo Starting hardware simulator in a separate window...
start "Hardware Simulator" cmd /k "node src/hardware/simulator/index.js"
if %ERRORLEVEL% NEQ 0 (
    echo WARNING: Failed to launch hardware simulator window.
    set "ERRORS=!ERRORS!1"
)

:: --------------------------------------------------------------------
:: 3) Next.js dev server
:: --------------------------------------------------------------------
echo [3/3] Next.js dev server...
cd /d "%REPO_DIR%"
echo Running: npx next dev --turbopack
echo The app will be available at http://localhost:3000 unless the port is busy.
echo.

npx next dev --turbopack

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo WARNING: Next.js dev server exited with code %ERRORLEVEL%.
    set "ERRORS=!ERRORS!!ERRORLEVEL!"
) else (
    echo.
    echo Next.js dev server stopped.
)

echo.
echo ============================================
echo  Full system runner finished.
echo  If emulators were skipped, run: npm run emu
echo ============================================
echo.

if "!ERRORS!" NEQ "" (
    echo One or more parts reported issues. Press any key to close this window...
    pause >/dev/null
)
endlocal
