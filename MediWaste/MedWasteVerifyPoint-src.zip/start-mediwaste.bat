@echo off
setlocal EnableDelayedExpansion

:: ============================================================================
:: MedWaste VerifyPoint - startup script
:: Starts the Firebase emulators and the Next.js dev server.
::
:: Toolkit-only notes:
::   - Firebase emulators require firebase-tools on PATH (npm i -g firebase-tools)
::     or the repo's firebase CLI. If unavailable, this script warns and skips them.
::   - The Next.js app is started by npx next dev (no global install required).
:: ============================================================================

set "REPO_DIR=%~dp0"
set "ERRORS=0"

echo ============================================
echo  MedWaste VerifyPoint - startup script
echo  Working directory: %REPO_DIR%
echo ============================================
echo.

:: --------------------------------------------------------------------
:: 1) Optional: start Firebase emulators (auth + firestore)
:: --------------------------------------------------------------------
echo [1/2] Checking Firebase CLI availability...
where firebase >/dev/null 2>/dev/null
if %ERRORLEVEL% NEQ 0 (
    echo WARNING: 'firebase' not found on PATH.
    echo         Install with:  npm install -g firebase-tools
    echo         Or run the emulators manually with:  npm run emu
    echo.
    set "SKIP_EMU=1"
) else (
    echo Firebase CLI found.
    echo.
    echo Starting Firebase emulators (auth, firestore) in a separate window...
    echo Press Ctrl+C in that window to stop them.
    echo.

    cd /d "%REPO_DIR%"
    start "Firebase Emulators" cmd /k "firebase emulators:start --only auth,firestore"
    if %ERRORLEVEL% NEQ 0 (
        echo WARNING: Failed to launch Firebase emulators window.
        set "ERRORS=!ERRORS!1"
    )
)

echo.
echo [2/2] Starting Next.js dev server...
echo.

:: --------------------------------------------------------------------
:: 2) Start the Next.js dev server
:: --------------------------------------------------------------------
cd /d "%REPO_DIR%"

:: If a .env.local exists, Next.js reads it automatically; otherwise falls back to .env.example values.
echo Running: npx next dev --turbopack
echo (The app will be available at http://localhost:3000 unless the port is busy)
echo.

npx next dev --turbopack

:: If the server exits, report it.
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo WARNING: Next.js dev server exited with code %ERRORLEVEL%.
    set "ERRORS=!ERRORS!!ERRORLEVEL!"
) else (
    echo.
    echo Next.js dev server stopped.
)

echo.
echo ============================================
echo  Startup complete.
echo  If emulators were skipped, run: npm run emu
echo  To run the hardware simulator:       npm run simulator
echo ============================================
echo.

:: --------------------------------------------------------------------
:: Keep the window open if there were errors, otherwise exit cleanly
:: --------------------------------------------------------------------
if "!ERRORS!" NEQ "" (
    echo One or more parts reported issues. Press any key to close this window...
    pause >/dev/null
)
endlocal
