"use client";

import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  ReactNode,
} from "react";
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut as fbSignOut,
  onAuthStateChanged,
  User as FirebaseUser,
} from "firebase/auth";
import { auth, useEmulators } from "@/lib/firebase";

interface AuthContextValue {
  user: FirebaseUser | null;
  loading: boolean;
  role: string | null;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

// Default emulator flag for local development. Override with env / UI.
const USE_EMULATORS = true;

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [role, setRole] = useState<string | null>(null);

  useEffect(() => {
    if (USE_EMULATORS) {
      useEmulators(true);
    }

    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      setUser(fbUser);
      setLoading(false);
      if (fbUser) {
        // In production this reads the role from a users collection.
        // For local emulator dev we store role on a custom claim or a
        // users/{uid} doc. Here we read from localStorage as a simple
        // placeholder seeded by settings/login flow.
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const saved = (typeof localStorage !== "undefined"
          ? (localStorage as any).medwasteUserRole
          : null);
        setRole(saved ?? "viewer");
      } else {
        setRole(null);
      }
    });

    return unsubscribe;
  }, []);

  const signIn = useCallback(
    async (email: string, password: string) => {
      await signInWithEmailAndPassword(auth, email, password);
      // After sign in, load any saved role from localStorage if present.
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      if (typeof localStorage !== "undefined") {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        setRole((localStorage as any).medwasteUserRole ?? "viewer");
      }
    },
    []
  );

  const signUp = useCallback(
    async (email: string, password: string) => {
      await createUserWithEmailAndPassword(auth, email, password);
    },
    []
  );

  const signOut = useCallback(async () => {
    await fbSignOut(auth);
  }, []);

  return (
    <AuthContext.Provider
      value={{ user, loading, role, signIn, signUp, signOut }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return ctx;
}

// Helper to persist role in localStorage (simple placeholder for emulator demo).
export function setUserRole(role: string) {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  if (typeof localStorage !== "undefined") (localStorage as any).medwasteUserRole = role;
}

export function getUserRoleSaved() {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return (typeof localStorage !== "undefined"
    ? (localStorage as any).medwasteUserRole
    : null) as string | null;
}
