"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useAuth } from "@/components/auth-context";
import {
  LayoutDashboard,
  Package,
  ClipboardList,
  Search,
  Settings,
  Radio,
  ArrowLeftRight,
  Receipt,
  FileSpreadsheet,
  ShieldCheck,
} from "lucide-react";

const navItems = [
  { href: "/overview", label: "Overview", icon: LayoutDashboard },
  { href: "/donations", label: "Donations", icon: Package },
  { href: "/donations/new", label: "New intake", icon: ClipboardList },
  { href: "/review", label: "Review", icon: Search },
  { href: "/station", label: "Station", icon: Radio },
  { href: "/handovers", label: "Handovers", icon: ArrowLeftRight },
  { href: "/dispositions", label: "Dispositions", icon: Receipt },
  { href: "/reports", label: "Reports", icon: FileSpreadsheet },
  { href: "/settings", label: "Settings", icon: Settings },
];

export function AppShell({ children }: { children: React.ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);
  const pathname = usePathname();
  const { user, signOut, loading, role } = useAuth();

  return (
    <div className="flex h-screen bg-white text-slate-900">
      {/* Sidebar */}
      <aside
        className={`${collapsed ? "w-16" : "w-60"} flex flex-col border-r border-slate-200 bg-white transition-all duration-200`}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 border-b border-slate-200 px-4 py-4">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-medical-900 text-white">
            <ShieldCheck className="h-5 w-5" />
          </div>
          {!collapsed && (
            <div className="flex flex-col leading-tight">
              <span className="text-sm font-semibold text-medical-900">MedWaste</span>
              <span className="text-[11px] font-medium text-slate-500 uppercase tracking-wide">
                VerifyPoint
              </span>
            </div>
          )}
        </div>

        {/* Nav */}
        <nav className="flex-1 space-y-1 px-3 py-4">
          {navItems.map((item) => {
            const active = pathname === item.href ||
              (item.href !== "/overview" && pathname.startsWith(item.href));
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                  active
                    ? "bg-medical-50 text-medical-700"
                    : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
                }`}
              >
                <item.icon className="h-4 w-4 shrink-0" />
                {!collapsed && <span className="truncate">{item.label}</span>}
              </Link>
            );
          })}
        </nav>

        {/* Collapse toggle */}
        <button
          onClick={() => setCollapsed((v) => !v)}
          className="mb-2 flex items-center justify-center gap-2 border-t border-slate-200 px-4 py-2 text-xs font-medium text-slate-500 hover:bg-slate-100"
        >
          {collapsed ? "→" : "←"}
          {!collapsed && <span>Collapse</span>}
        </button>

        {/* User / sign out */}
        <div className="border-t border-slate-200 p-3">
          {user ? (
            <div className="flex items-center gap-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-medical-100 text-medical-700 text-sm font-semibold">
                {user.displayName?.[0] ?? user.email?.[0] ?? "?"}
              </div>
              {!collapsed && (
                <div className="flex flex-col leading-tight min-w-0">
                  <span className="text-sm font-medium text-slate-900 truncate">
                    {user.displayName ?? user.email}
                  </span>
                  <span className="text-[11px] text-slate-500">{role ?? "viewer"}</span>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center text-xs text-slate-500">Signed out</div>
          )}
          <button
            onClick={signOut}
            className="mt-2 w-full rounded-lg px-3 py-1.5 text-xs font-medium text-slate-600 transition-colors hover:bg-slate-100 hover:text-slate-900"
            disabled={loading}
          >
            Sign out
          </button>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar */}
        <header className="flex items-center justify-between border-b border-slate-200 bg-white px-6 py-3">
          <div className="flex items-center gap-3 text-sm text-slate-500">
            <span className="hidden sm:inline">MedWaste VerifyPoint</span>
            <span className="hidden sm:inline">·</span>
            <span className="text-slate-400">{pathname}</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-green-50 px-2.5 py-1 text-xs font-medium text-green-700">
              <span className="h-1.5 w-1.5 rounded-full bg-green-500" />
              Emulator mode
            </span>
          </div>
        </header>

        {/* Content */}
        <div className="flex-1 overflow-auto p-6">{children}</div>
      </main>
    </div>
  );
}
