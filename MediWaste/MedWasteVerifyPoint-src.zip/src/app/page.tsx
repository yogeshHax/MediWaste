import { redirect } from "next/navigation";
import { ShieldCheck, Package, Radio, ClipboardList, ArrowRight } from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function HomePage() {
  return (
    <div className="flex min-h-screen flex-col bg-white">
      {/* Minimal header for landing */}
      <header className="border-b border-slate-200 bg-white px-6 py-4">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-medical-900 text-white">
            <ShieldCheck className="h-5 w-5" />
          </div>
          <div className="flex flex-col leading-tight">
            <span className="text-sm font-semibold text-medical-900">MedWaste</span>
            <span className="text-[11px] font-medium text-slate-500 uppercase tracking-wide">VerifyPoint</span>
          </div>
          <span className="ml-auto text-xs text-slate-400">Local emulator demo</span>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center px-6 py-16">
        <div className="max-w-2xl text-center">
          <div className="mb-6 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-medical-50 text-medical-700">
            <ShieldCheck className="h-8 w-8" />
          </div>
          <h1 className="text-3xl font-semibold tracking-tight text-slate-900 sm:text-4xl">
            Medicine-waste intake, verification & review
          </h1>
          <p className="mx-auto mt-4 max-w-lg text-base leading-relaxed text-slate-500">
            MedWaste VerifyPoint connects a physical verification station to a professional web application.
            Register packages, inspect and verify donations, manage discrepancies, and track chain of custody.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3 text-sm text-slate-500">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-3 py-1 text-slate-700">
              <Package className="h-4 w-4" /> 12 workflows
            </span>
            <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-3 py-1 text-slate-700">
              <Radio className="h-4 w-4" /> Hardware station
            </span>
            <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-3 py-1 text-slate-700">
              <ClipboardList className="h-4 w-4" /> Chain of custody
            </span>
          </div>
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
            <Link href="/overview">
              <Button size="lg" className="gap-2">
                Open dashboard
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
            <Link href="/simulator">
              <Button variant="outline" size="lg" className="gap-2">
                Open simulator
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
          <p className="mt-8 text-xs text-slate-400">
            This is a local development build. In production, authentication, data, and backend logic are provided by Firebase.
          </p>
        </div>
      </main>
    </div>
  );
}
