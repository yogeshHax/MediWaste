# Hardware

This module contains the physical-station software: firmware, bridge, and simulator.

## Components

- `firmware/VerifyPoint.ino` — Arduino UNO firmware.
- `firmware/README.md` — firmware setup, wiring, protocol, calibration, safety.
- `bridge/index.ts` — Node.js serial/Bluetooth bridge (production path).
- `simulator/index.ts` — hardware simulator (dev/demo path).

## How they fit together

1. The Arduino firmware runs on the physical station.
2. The Node.js bridge connects to the Arduino over serial (USB) or Bluetooth (HC-05),
   sends commands, and receives sensor/state events.
3. The app's station console and command queue talk to the bridge. The backend validates
   and authorises commands before they reach the device.
4. The simulator mirrors the firmware protocol so the full workflow can be demonstrated
   without hardware.

## Protocol

The firmware and simulator share a simple text-line protocol (newline-terminated):

Commands:

- `OPEN_GATE`
- `CLOSE_GATE`
- `SET_SERVO <angle>`
- `LCD <text>`
- `LED <green|amber|red|off>`
- `BEEP <ms>`

Events:

- `HB` — heartbeat
- `IR <0|1>` — IR object detected
- `US <cm>` — ultrasonic distance
- `GATE <open|closed>` — gate state
- `SERVO <angle>` — servo position
- `LCD <text>` — LCD content
- `LED <colour>` — status LED

## Safety

- Gate default is CLOSED.
- Sensor readings do not authorise acceptance.
- Backend validates and authorises commands before the device executes them.
- This is not a certified pharmaceutical authentication device.

## Running the simulator

```bash
npm run simulator
```

Or import `src/hardware/simulator/index.ts` and call `startSimulator()` from a script.
The simulator pushes events into the same event store the app reads from.

## Running the bridge (production)

The bridge is a Node process that opens the serial/Bluetooth connection to the Arduino,
sends commands from the station command queue, and receives events. Configure the port,
baud rate, and Bluetooth address via environment variables or options.
