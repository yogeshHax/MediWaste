import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth, Auth } from "firebase/auth";
import { getFirestore, Firestore } from "firebase/firestore";
import { z } from "zod";

// ---------------------------------------------------------------------------
// Firebase initialisation
// ---------------------------------------------------------------------------
// In production, set these via environment variables. Locally, the emulators
// are used. Never hardcode real credentials.
const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY ?? "",
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN ?? "",
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID ?? "",
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET ?? "",
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID ?? "",
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID ?? "",
};

let app;
let auth: Auth;
let db: Firestore;

if (process.env.NEXT_PUBLIC_USE_FIREBASE_EMULATORS === "true") {
  // When using emulators, initialise with a bare config and point the SDK
  // to the emulator hosts. This is set up in the app's layout/init code.
  app = getApps().length ? getApp() : initializeApp({
    projectId: firebaseConfig.projectId || "demo-project",
  });
} else {
  app = getApps().length ? getApp() : initializeApp(firebaseConfig);
}

auth = getAuth(app);
db = getFirestore(app);

// Point to emulators when the flag is set (client-side). This is also
// configured via useEmulators in the layout.
export function useEmulators(use: boolean) {
  if (!use || typeof window === "undefined") return;
  // Connect to locally running Firebase emulators.
  // These must be started separately (npm run emu).
  const host = window.location.hostname;
  const isLocal = host === "localhost" || host === "127.0.0.1" || host === "[::1]";
  if (!isLocal) return;

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const fb = (window as any).firebase;
  if (!fb) return;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  if (typeof (fb.auth?.useEmulator) === "function") fb.auth.useEmulator("http://localhost:9099");
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  if (typeof (fb.firestore?.useEmulator) === "function") fb.firestore.useEmulator("localhost", 8080);
}
export { app, auth, db };

// ---------------------------------------------------------------------------
// User helper
// ---------------------------------------------------------------------------
export async function getCurrentUser() {
  return auth.currentUser;
}

export async function fetchUserRole(uid: string): Promise<import("../types").User | null> {
  // In production this reads from a users collection. Locally we rely on the
  // emulator / seed data. Placeholder implementation.
  return null;
}
